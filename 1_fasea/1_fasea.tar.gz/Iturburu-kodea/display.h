#ifndef DISPLAY_H
#define DISPLAY_H

void display(void);
void reshape(int width, int height);

#endif // DISPLAY_H
